# Reactify

> A material design reactjs admin template

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm start

# build for production with minification
npm run build
```

For a detailed explanation on how things work, check out the [guide](https://github.com/facebook/create-react-app).
