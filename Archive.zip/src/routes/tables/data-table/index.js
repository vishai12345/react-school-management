import React, { Component, Fragment } from 'react';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import IconButton from '@material-ui/core/IconButton';
import TextField from '@material-ui/core/TextField';
import { withStyles } from "@material-ui/core/styles";
import PropTypes from 'prop-types';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Tooltip from '@material-ui/core/Tooltip';
import Typography from '@material-ui/core/Typography';
import DeleteIcon from '@material-ui/icons/Delete';
import { lighten } from '@material-ui/core/styles/colorManipulator';
import $ from 'jquery'
import mixitup from 'mixitup';
// rct card box
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

function desc(a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getSorting(order, orderBy) {
  return order === 'desc' ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
}

const rows = [
  { id: 'assessmentNum', numeric: false, disablePadding: true, label: 'Assessment Number' },
  { id: 'assessmentName', numeric: false, disablePadding: false, label: 'Assessment Name' },
  { id: 'assessmentCreated', numeric: false, disablePadding: false, label: 'Created' },
  { id: 'assessmentModified', numeric: false, disablePadding: false, label: 'Modified' },
	{ id: 'assessmentStatus', numeric: false, disablePadding: false, label: 'Status' },
	{ id: 'assessmentResponse', numeric: false, disablePadding: false, label: 'Response' },
];

const styles = theme => ({
	root: {
	  color: theme.palette.text.primary
	},
	icon: {
	  margin: theme.spacing.unit,
	  fontSize: 32
	},
	tableCellRoot: {
		padding : '0px',
		'border-bottom': '0px',
		backgroundColor: 'white'
	},
	tableCellHead: {
		fontSize: '15px',
	},
	tableUpperCellRoot: {
		backgroundColor: 'white',
		padding : '0px',
	},
	tableHeadRoot: {
		zIndex: 999
	}
});

class EnhancedTableHead extends React.Component {
  createSortHandler = property => event => {
    this.props.onRequestSort(event, property);
  };

  render() {
		const { classes } = this.props
    const { onSelectAllClick, order, orderBy, numSelected, rowCount } = this.props;
    return (
      <TableHead classes={{
				root: classes.tableHeadRoot
			}}>
        <TableRow >
          <TableCell classes={{root: classes.tableUpperCellRoot}}>
            <Checkbox
              indeterminate={numSelected > 0 && numSelected < rowCount}
              checked={numSelected === rowCount}
              onChange={onSelectAllClick}
            />
          </TableCell>
          {rows.map(row => {
            return (
              <TableCell
                key={row.id}
								numeric={row.numeric}
								classes={{
									head: classes.tableCellHead,
									root: classes.tableUpperCellRoot
								}}
                padding={row.disablePadding ? 'none' : 'default'}
                sortDirection={orderBy === row.id ? order : false}
              >
                <TableSortLabel
                    active={orderBy === row.id}
                    direction={order}
                    onClick={this.createSortHandler(row.id)}
                  >
                    {row.label}
                  </TableSortLabel>
              </TableCell>
            );
					}, this)}
					<TableCell classes={{root: classes.tableUpperCellRoot}}>
						<TableSortLabel>
								Actions
						</TableSortLabel>
          </TableCell>
        </TableRow>
      </TableHead>
    );
  }
}

EnhancedTableHead.propTypes = {
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired,
};

const toolbarStyles = theme => ({
  root: {
    paddingRight: theme.spacing.unit,
  },
  highlight:
    theme.palette.type === 'light'
      ? {
          color: theme.palette.secondary.main,
          backgroundColor: lighten(theme.palette.secondary.light, 0.85),
        }
      : {
          color: theme.palette.text.primary,
          backgroundColor: theme.palette.secondary.dark,
        },
  spacer: {
    flex: '1 1 100%',
  },
  actions: {
    color: theme.palette.text.secondary,
  },
  title: {
    flex: '0 0 auto',
  },
});
class EnhancedTableToolbar extends React.Component{

	constructor(props){
		super(props)
		this.state = {
			serachIconPressed : false,
			searchText: '',
			isBredcrumbPressed: false
		}
	}

	bredcrumbPressed = () => {
		this.setState({ isBredcrumbPressed: !this.state.isBredcrumbPressed }, () => {
			this.props.bredcrumbPressed()
		})
	}

	searchByName = (e) => {
		this.setState({ searchText: e.target.value }, () => {
			this.props.searchByName(this.state.searchText)
		})
	}
	render(){
		const { numSelected } = this.props;
		return (
				<div className='flex-box-search'>
					<div className='inner-flex-box-search'>
					{
						numSelected > 0 ? 
							<Typography color="inherit" variant="subheading">
								{numSelected} selected
							</Typography> 
						: 
							!this.state.serachIconPressed ? <p style={{ fontSize: '16px' }}>Survey List</p> :
								<div className='searchBox-container'>
									<TextField 
										id="with-placeholder" fullWidth
										value={this.state.searchText} onChange={this.searchByName}
										placeholder={`Search`}/>
									<IconButton onClick={() => this.setState({ serachIconPressed: false })}>
										<i className="material-icons">clear</i>
									</IconButton>
								</div>
					}
					</div>
						{numSelected > 0 ? (
							<Tooltip title="Delete">
								<IconButton aria-label="Delete">
									<DeleteIcon />
								</IconButton>
							</Tooltip>
						) : (
							<div className='icon-container' >
								{
									!this.state.isBredcrumbPressed && <Tooltip title="Search">
										<IconButton onClick={() => this.setState({ serachIconPressed: true })}>
											<i className="material-icons">search</i>
										</IconButton>
									</Tooltip>
								}	
								{
									!this.state.isBredcrumbPressed && <Tooltip title="Download CSV">
										<IconButton onClick={() => this.props.downloadCSV()}>
											<i className="material-icons">vertical_align_bottom</i>
										</IconButton>
									</Tooltip>
								}
								{
									!this.state.isBredcrumbPressed && <Tooltip title="Print list">
										<IconButton onClick={() => this.props.printData()}>
											<i className="material-icons">local_printshop</i>
										</IconButton>
									</Tooltip>
								}	
								{
									!this.state.isBredcrumbPressed && <Tooltip title="View Columns">
										<IconButton>
											<i className="material-icons">view_column</i>
										</IconButton>
									</Tooltip>
								}	
								{
									!this.state.isBredcrumbPressed && <Tooltip title="Filter list">
										<IconButton>
											<i className="material-icons">filter_list</i>
										</IconButton>
									</Tooltip>
								}	
								<IconButton onClick={this.bredcrumbPressed}>
										<i style={{ marginRight: '-12px' }} className="material-icons">keyboard_arrow_left</i>
										<i className="material-icons">keyboard_arrow_right</i>
								</IconButton>
							</div>
						)}
				</div>
		);
	}
}


EnhancedTableToolbar.propTypes = {
  classes: PropTypes.object.isRequired,
  numSelected: PropTypes.number.isRequired,
};

EnhancedTableToolbar = withStyles(toolbarStyles)(EnhancedTableToolbar);

// For Basic Table
let id = 0;

function createData(assNum, assName, created, modified, status, response) {
	id += 1;
	return { id, assNum, assName, created, modified, status, response };
}

const data = [
	createData("Gabby George", "Aaren Rose", "15-09-2018", "15-09-2018", 'Active', "Aaren Rose"),
	createData("Aiden Lloyd", "Gabby George", "16-09-2018", "15-09-2018", 'Active', "Gabby George"),
	createData("Jaden Collins", "Aiden Lloyd", "13-09-2018", "16-09-2018", 'Active', "Aiden Lloyd"),
	createData("Franky Rees", "Jaden Collins", "11-09-2018", "13-09-2018", 'Active', "Jaden Collins"),
	createData("Aaren Rose", "Franky Rees", "15-09-2018", "11-09-2018", 'Active', "Franky Rees"),
];

class BasicTable extends Component {

	constructor(props){
		super(props)
		this.state = {
			order: 'asc',
    	orderBy: 'assNum',
			selected: [],
			data: data,
			searchText: '',
			isBredcrumbPressed: false
		}
	}

	componentDidMount(){
		$('.pCard_add-1').click(function () {
				$('.pCard_card-1').toggleClass('pCard_on-1');
				$('.pCard_add-1 i').toggleClass('fa-minus');
		});

		mixitup('#portfoliolist', {
				selectors: {
						target: '.portfolio',
				},
				animation: {
						duration: 300
				}
		});
	}

	renderRow = (n) => {
		const { classes } = this.props
		const isSelected = this.isSelected(n.id);
		const searchText = this.state.searchText.trim()
		if(searchText && n.assName.toLowerCase().indexOf(searchText.toLowerCase()) === -1){
			return null
		}
		return (
			<TableRow
				hover role="checkbox"
				aria-checked={isSelected} tabIndex={-1} key={n.id} selected={isSelected}
			>
				<TableCell onClick={event => this.handleClick(event, n.id)} classes={{root: classes.tableCellRoot}}>
						<Checkbox checked={isSelected} />
				</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>{n.assNum}</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>{n.assName}</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>{n.created}</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>{n.modified}</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>{n.status}</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>{n.response}</TableCell>
				<TableCell classes={{root: classes.tableCellRoot}}>
					<div style={{ display: "inline-flex" }}>
						<i style={{ fontSize: '20px', marginRight: '5px' }} className="material-icons">edit</i>
						<i onClick={() => this.deleteRow(n.id)} style={{ fontSize: '20px', marginRight: '5px' }} className="material-icons">delete</i>
						<i onClick={() => this.copyRow(n.id)} style={{ fontSize: '20px', marginRight: '5px' }} className="material-icons">file_copy</i>
						<i style={{ fontSize: '20px', marginRight: '5px' }} className="material-icons">report</i>
						<i style={{ fontSize: '20px', marginRight: '5px' }} className="material-icons">unfold_more</i>
					</div>
				</TableCell>
			</TableRow>
		);
	}

	deleteRow(id){
		let { data } = this.state
		data.splice(data.findIndex(d => d.id === id), 1)
		this.setState({ data })
	}

	copyRow(id){
		let { data } = this.state
		data = [...data, data.find(d => d.id === id)]
		this.setState({ data })
	}

	handleRequestSort = (event, property) => {
    const orderBy = property;
    let order = 'desc';

    if (this.state.orderBy === property && this.state.order === 'desc') {
      order = 'asc';
    }

    this.setState({ order, orderBy });
  };

  handleSelectAllClick = (event, checked) => {
    if (checked) {
      this.setState(state => ({ selected: state.data.map(n => n.id) }));
      return;
    }
    this.setState({ selected: [] });
  };

  handleClick = (event, id) => {
    const { selected } = this.state;
    const selectedIndex = selected.indexOf(id);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, id);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      );
    }

    this.setState({ selected: newSelected });
	};
	
	isSelected = id => this.state.selected.indexOf(id) !== -1;

	downloadCSV = () => {
		const rows = [
			["Gabby George", "Aaren Rose", "15-09-2018", "15-09-2018", 'Active', "Aaren Rose"], 
			["Aiden Lloyd", "Gabby George", "16-09-2018", "15-09-2018", 'Active', "Gabby George"],
			["Jaden Collins", "Aiden Lloyd", "13-09-2018", "16-09-2018", 'Active', "Aiden Lloyd"],
			["Franky Rees", "Jaden Collins", "11-09-2018", "13-09-2018", 'Active', "Jaden Collins"],
			["Aaren Rose", "Franky Rees", "15-09-2018", "11-09-2018", 'Active', "Franky Rees"]
		];
		let csvContent = "data:text/csv;charset=utf-8,";
		rows.forEach(function(rowArray){
			let row = rowArray.join(",");
			csvContent += row + "\r\n";
		}); 

		var hiddenElement = document.createElement('a');
    hiddenElement.href = encodeURI(csvContent);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'User-Table.csv';
    hiddenElement.click();
	}

	printData = () => {
		var divToPrint=document.getElementById("printTable");
		var htmlToPrint = '' +
			'<style type="text/css">' +
			'table th, table td {' +
			'border:1px solid #000;' +
			'padding;0.5em;' +
			'}' +
			'</style>';
    	htmlToPrint += divToPrint.outerHTML;
		const newWin= window.open("");
		newWin.document.write(htmlToPrint);
		newWin.print();
		newWin.close();
	}

	searchByName = (searchText) => {
		this.setState({ searchText })
	}

	bredcrumbPressed = () => {
		this.setState({ isBredcrumbPressed: !this.state.isBredcrumbPressed })
	}

	render() {
		const { data, order, orderBy, selected } = this.state;
		return (
			<div className="table-wrapper pt-10 pb-20 pr-30 pl-30">
				<RctCollapsibleCard fullBlock>
					<div style={{ position: 'relative', zIndex: 999 }}>
					<EnhancedTableToolbar 
						numSelected={selected.length} 
						downloadCSV={this.downloadCSV}
						bredcrumbPressed={this.bredcrumbPressed}
						searchByName={this.searchByName}
						printData={this.printData}/>
					<div className="table-responsive"
						style={{
							transform: `translate(0px, ${this.state.isBredcrumbPressed ? 500 : 0}px)`,
							transition: 'transform 500ms ease-in-out',
							opacity: this.state.isBredcrumbPressed ? 0 : 1,
							zIndex: this.state.isBredcrumbPressed ? -99 : 999,
						}}
					>
						<Table id='printTable'>
							<EnhancedTableHead
								{...this.props}
								numSelected={selected.length}
								order={order}
								orderBy={orderBy}
								onSelectAllClick={this.handleSelectAllClick}
								onRequestSort={this.handleRequestSort}
								rowCount={data.length}
							/>
							<TableBody>
								<Fragment>
									{data.sort(getSorting(order, orderBy)).map(this.renderRow)}
								</Fragment>
							</TableBody>
						</Table>
					</div>
					</div>
					<div className=""
						style={{
							transform: `translate(0px, ${this.state.isBredcrumbPressed ? -270 : -800}px)`,
							transition: 'transform 500ms ease-in-out',
							opacity: this.state.isBredcrumbPressed ? 1 : 0,
							zIndex: this.state.isBredcrumbPressed ? 1 : -99,
						}}
					>
						<div className="source">
							<div className="highlight">
									<div className="row">
											<div className="container">
													<div className="col-12">
															{/* <div className="dropdown mx-auto mt-1" style={{ width: '100px' }}>
																	<button className="btn btn-secondary dropdown-toggle mt-1 fuse-ripple-ready" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																			Filter
																	</button>
																	<div className="dropdown-menu" id="filters" aria-labelledby="dropdownMenuButton">
																			<button className="dropdown-item filter fuse-ripple-ready" data-filter=".emp, .cli, .stu, .cit">All</button>
																			<button className="dropdown-item filter fuse-ripple-ready active" data-filter=".emp">Employee</button>
																			<button className="dropdown-item filter fuse-ripple-ready" data-filter=".cli">Client</button>
																			<button className="dropdown-item filter fuse-ripple-ready" data-filter=".stu">Student</button>
																			<button className="dropdown-item filter fuse-ripple-ready" data-filter=".cit">Cities</button>
																	</div>
															</div> */}

															<div id="portfoliolist">
															<div className="col-md-2 col-sm-4 col-xs-6 portfolio emp" data-cat="emp" style={{ display: 'inline-block' }} data-bound="">
																		<div className="pCard_card-1">
																						<div className="pCard_up-1">
																								<div className="pCard_text-1">
																										<h6>
																												<strong>Card 1
																												</strong>
																										</h6>
																								</div>
																								<div className="pCard_add-1">
																										<i className="fa fa-plus"></i>
																								</div>
																						</div>
																						<div className="pCard_down-1">
																								<div>
																										<p>
																												<strong>Views</strong>
																										</p>
																										<p>
																												<strong>26</strong>
																										</p>
																								</div>
																								<div>
																										<p></p>
																										<p></p>
																								</div>
																								<div>
																										<p>
																												<strong>Used</strong>
																										</p>
																										<p>
																												<strong>976</strong>
																										</p>
																								</div>
																						</div>
																						<div className="pCard_back-1">
																								<p>Lorem ipsum dolorsit
																										ametconsectetur
																										adipisicingelit.
																										Suntquibusdam
																										assumenda pariatur,voluptas
																										quae esse
																								</p>
																						</div>
																				</div>
																	</div>
																	<div className="col-md-2 col-sm-4 col-xs-6 portfolio emp" data-cat="emp" style={{ display: 'inline-block' }} data-bound="">
																		<div className="pCard_card-1">
																						<div className="pCard_up-1">
																								<div className="pCard_text-1">
																										<h6>
																												<strong>Card 1
																												</strong>
																										</h6>
																								</div>
																								<div className="pCard_add-1">
																										<i className="fa fa-plus"></i>
																								</div>
																						</div>
																						<div className="pCard_down-1">
																								<div>
																										<p>
																												<strong>Views</strong>
																										</p>
																										<p>
																												<strong>26</strong>
																										</p>
																								</div>
																								<div>
																										<p></p>
																										<p></p>
																								</div>
																								<div>
																										<p>
																												<strong>Used</strong>
																										</p>
																										<p>
																												<strong>976</strong>
																										</p>
																								</div>
																						</div>
																						<div className="pCard_back-1">
																								<p>Lorem ipsum dolorsit
																										ametconsectetur
																										adipisicingelit.
																										Suntquibusdam
																										assumenda pariatur,voluptas
																										quae esse
																								</p>
																						</div>
																				</div>
																	</div>
																	<div className="col-md-2 col-sm-4 col-xs-6 portfolio emp" data-cat="emp" style={{ display: 'inline-block' }} data-bound="">
																		<div className="pCard_card-1">
																						<div className="pCard_up-1">
																								<div className="pCard_text-1">
																										<h6>
																												<strong>Card 1
																												</strong>
																										</h6>
																								</div>
																								<div className="pCard_add-1">
																										<i className="fa fa-plus"></i>
																								</div>
																						</div>
																						<div className="pCard_down-1">
																								<div>
																										<p>
																												<strong>Views</strong>
																										</p>
																										<p>
																												<strong>26</strong>
																										</p>
																								</div>
																								<div>
																										<p></p>
																										<p></p>
																								</div>
																								<div>
																										<p>
																												<strong>Used</strong>
																										</p>
																										<p>
																												<strong>976</strong>
																										</p>
																								</div>
																						</div>
																						<div className="pCard_back-1">
																								<p>Lorem ipsum dolorsit
																										ametconsectetur
																										adipisicingelit.
																										Suntquibusdam
																										assumenda pariatur,voluptas
																										quae esse
																								</p>
																						</div>
																				</div>
																	</div>
																	<div className="col-md-2 col-sm-4 col-xs-6 portfolio emp" data-cat="emp" style={{ display: 'inline-block' }} data-bound="">
																		<div className="pCard_card-1">
																						<div className="pCard_up-1">
																								<div className="pCard_text-1">
																										<h6>
																												<strong>Card 1
																												</strong>
																										</h6>
																								</div>
																								<div className="pCard_add-1">
																										<i className="fa fa-plus"></i>
																								</div>
																						</div>
																						<div className="pCard_down-1">
																								<div>
																										<p>
																												<strong>Views</strong>
																										</p>
																										<p>
																												<strong>26</strong>
																										</p>
																								</div>
																								<div>
																										<p></p>
																										<p></p>
																								</div>
																								<div>
																										<p>
																												<strong>Used</strong>
																										</p>
																										<p>
																												<strong>976</strong>
																										</p>
																								</div>
																						</div>
																						<div className="pCard_back-1">
																								<p>Lorem ipsum dolorsit
																										ametconsectetur
																										adipisicingelit.
																										Suntquibusdam
																										assumenda pariatur,voluptas
																										quae esse
																								</p>
																						</div>
																				</div>
																	</div>
															</div>
													</div>
											</div>
									</div>
							</div>
					</div>
					</div>
				</RctCollapsibleCard>
			</div>
		);
	}
}
BasicTable.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired,
};

export default withStyles(styles, { withTheme: true })(BasicTable);